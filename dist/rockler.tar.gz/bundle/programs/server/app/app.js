var require = meteorInstall({"collections":{"Sessions.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// collections/Sessions.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  Sessions: () => Sessions
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Sessions = new Mongo.Collection('sessions');
///////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Sessions;
module.watch(require("../collections/Sessions"), {
  Sessions(v) {
    Sessions = v;
  }

}, 1);
WebApp.connectHandlers.use("/hear", (req, res, next) => {
  const machine = req.url.match(/^\/(.*)$/)[1];
  let session = Sessions.findOne({
    machine
  }); // Create session

  if (!session) {
    session = {
      machine,
      create_at: new Date(),
      last_pull: new Date(0),
      commands: []
    };
    session._id = Sessions.insert(session);
  } // Update last conection


  Sessions.update(session._id, {
    $set: {
      last_pull: new Date()
    }
  });
  let cmdId = -1;
  session.commands.forEach((cmd, ix) => {
    if (cmdId !== -1) return;
    if (cmd.status === 'pending') cmdId = ix;
  });

  if (cmdId === -1) {
    res.writeHead(204);
    return res.end();
  }

  const command = session.commands[cmdId];
  res.writeHead(200);
  res.end(JSON.stringify({
    id: cmdId,
    cmd: command.command
  }));
});
WebApp.connectHandlers.use("/talk", (req, res, next) => {
  const machine = req.url.match(/^\/(.*)$/)[1];
  let session = Sessions.findOne({
    machine
  });
  let body = '';
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', Meteor.bindEnvironment(function () {
    try {
      body = JSON.parse(body);
    } catch (error) {
      res.writeHead(400);
      return res.end();
    }

    const cid = body.id;
    const setter = {
      $set: {
        ['commands.' + cid + '.answered_at']: new Date(),
        ['commands.' + cid + '.status']: 'done',
        ['commands.' + cid + '.cmdStatus']: body.cmdStatus,
        ['commands.' + cid + '.stdout']: body.stdout,
        ['commands.' + cid + '.stderr']: body.stderr
      }
    };
    Sessions.update(session._id, setter);
    res.writeHead(200);
    res.end();
  }));
});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/Sessions.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvU2Vzc2lvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIlNlc3Npb25zIiwiTW9uZ28iLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiQ29sbGVjdGlvbiIsIk1ldGVvciIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlcyIsIm5leHQiLCJtYWNoaW5lIiwidXJsIiwibWF0Y2giLCJzZXNzaW9uIiwiZmluZE9uZSIsImNyZWF0ZV9hdCIsIkRhdGUiLCJsYXN0X3B1bGwiLCJjb21tYW5kcyIsIl9pZCIsImluc2VydCIsInVwZGF0ZSIsIiRzZXQiLCJjbWRJZCIsImZvckVhY2giLCJjbWQiLCJpeCIsInN0YXR1cyIsIndyaXRlSGVhZCIsImVuZCIsImNvbW1hbmQiLCJKU09OIiwic3RyaW5naWZ5IiwiaWQiLCJib2R5Iiwib24iLCJjaHVuayIsImJpbmRFbnZpcm9ubWVudCIsInBhcnNlIiwiZXJyb3IiLCJjaWQiLCJzZXR0ZXIiLCJjbWRTdGF0dXMiLCJzdGRvdXQiLCJzdGRlcnIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJQyxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsUUFBTUcsQ0FBTixFQUFRO0FBQUNILFlBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFMUMsTUFBTUosV0FBVyxJQUFJQyxNQUFNSSxVQUFWLENBQXFCLFVBQXJCLENBQWpCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSUMsTUFBSjtBQUFXUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNHLFNBQU9GLENBQVAsRUFBUztBQUFDRSxhQUFPRixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlKLFFBQUo7QUFBYUYsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHlCQUFSLENBQWIsRUFBZ0Q7QUFBQ0gsV0FBU0ksQ0FBVCxFQUFXO0FBQUNKLGVBQVNJLENBQVQ7QUFBVzs7QUFBeEIsQ0FBaEQsRUFBMEUsQ0FBMUU7QUFHdkZHLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLE9BQTNCLEVBQW9DLENBQUNDLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQ3RELFFBQU1DLFVBQVVILElBQUlJLEdBQUosQ0FBUUMsS0FBUixDQUFjLFVBQWQsRUFBMEIsQ0FBMUIsQ0FBaEI7QUFFQSxNQUFJQyxVQUFVaEIsU0FBU2lCLE9BQVQsQ0FBaUI7QUFDN0JKO0FBRDZCLEdBQWpCLENBQWQsQ0FIc0QsQ0FPdEQ7O0FBQ0EsTUFBSSxDQUFDRyxPQUFMLEVBQWM7QUFDWkEsY0FBVTtBQUNSSCxhQURRO0FBRVJLLGlCQUFXLElBQUlDLElBQUosRUFGSDtBQUdSQyxpQkFBVyxJQUFJRCxJQUFKLENBQVMsQ0FBVCxDQUhIO0FBSVJFLGdCQUFVO0FBSkYsS0FBVjtBQU9BTCxZQUFRTSxHQUFSLEdBQWN0QixTQUFTdUIsTUFBVCxDQUFnQlAsT0FBaEIsQ0FBZDtBQUNELEdBakJxRCxDQW1CdEQ7OztBQUNBaEIsV0FBU3dCLE1BQVQsQ0FBZ0JSLFFBQVFNLEdBQXhCLEVBQTZCO0FBQzNCRyxVQUFNO0FBQ0pMLGlCQUFXLElBQUlELElBQUo7QUFEUDtBQURxQixHQUE3QjtBQU1BLE1BQUlPLFFBQVEsQ0FBQyxDQUFiO0FBQ0FWLFVBQVFLLFFBQVIsQ0FBaUJNLE9BQWpCLENBQXlCLENBQUNDLEdBQUQsRUFBTUMsRUFBTixLQUFhO0FBQ3BDLFFBQUlILFVBQVUsQ0FBQyxDQUFmLEVBQWtCO0FBQ2xCLFFBQUlFLElBQUlFLE1BQUosS0FBZSxTQUFuQixFQUE4QkosUUFBUUcsRUFBUjtBQUMvQixHQUhEOztBQUtBLE1BQUlILFVBQVUsQ0FBQyxDQUFmLEVBQWtCO0FBQ2hCZixRQUFJb0IsU0FBSixDQUFjLEdBQWQ7QUFDQSxXQUFPcEIsSUFBSXFCLEdBQUosRUFBUDtBQUNEOztBQUVELFFBQU1DLFVBQVVqQixRQUFRSyxRQUFSLENBQWlCSyxLQUFqQixDQUFoQjtBQUVBZixNQUFJb0IsU0FBSixDQUFjLEdBQWQ7QUFDQXBCLE1BQUlxQixHQUFKLENBQVFFLEtBQUtDLFNBQUwsQ0FBZTtBQUNyQkMsUUFBSVYsS0FEaUI7QUFFckJFLFNBQUtLLFFBQVFBO0FBRlEsR0FBZixDQUFSO0FBSUQsQ0E1Q0Q7QUE4Q0ExQixPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQixPQUEzQixFQUFvQyxDQUFDQyxHQUFELEVBQU1DLEdBQU4sRUFBV0MsSUFBWCxLQUFvQjtBQUN0RCxRQUFNQyxVQUFVSCxJQUFJSSxHQUFKLENBQVFDLEtBQVIsQ0FBYyxVQUFkLEVBQTBCLENBQTFCLENBQWhCO0FBRUEsTUFBSUMsVUFBVWhCLFNBQVNpQixPQUFULENBQWlCO0FBQzdCSjtBQUQ2QixHQUFqQixDQUFkO0FBSUEsTUFBSXdCLE9BQU8sRUFBWDtBQUNBM0IsTUFBSTRCLEVBQUosQ0FBTyxNQUFQLEVBQWUsVUFBU0MsS0FBVCxFQUFnQjtBQUM3QkYsWUFBUUUsS0FBUjtBQUNELEdBRkQ7QUFJQTdCLE1BQUk0QixFQUFKLENBQU8sS0FBUCxFQUFjaEMsT0FBT2tDLGVBQVAsQ0FBdUIsWUFBVztBQUM5QyxRQUFJO0FBQ0ZILGFBQU9ILEtBQUtPLEtBQUwsQ0FBV0osSUFBWCxDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU9LLEtBQVAsRUFBYztBQUNkL0IsVUFBSW9CLFNBQUosQ0FBYyxHQUFkO0FBQ0EsYUFBT3BCLElBQUlxQixHQUFKLEVBQVA7QUFDRDs7QUFFRCxVQUFNVyxNQUFNTixLQUFLRCxFQUFqQjtBQUVBLFVBQU1RLFNBQVM7QUFDYm5CLFlBQU07QUFDSixTQUFDLGNBQWNrQixHQUFkLEdBQW9CLGNBQXJCLEdBQXNDLElBQUl4QixJQUFKLEVBRGxDO0FBRUosU0FBQyxjQUFjd0IsR0FBZCxHQUFvQixTQUFyQixHQUFpQyxNQUY3QjtBQUdKLFNBQUMsY0FBY0EsR0FBZCxHQUFvQixZQUFyQixHQUFvQ04sS0FBS1EsU0FIckM7QUFJSixTQUFDLGNBQWNGLEdBQWQsR0FBb0IsU0FBckIsR0FBaUNOLEtBQUtTLE1BSmxDO0FBS0osU0FBQyxjQUFjSCxHQUFkLEdBQW9CLFNBQXJCLEdBQWlDTixLQUFLVTtBQUxsQztBQURPLEtBQWY7QUFVQS9DLGFBQVN3QixNQUFULENBQWdCUixRQUFRTSxHQUF4QixFQUE2QnNCLE1BQTdCO0FBRUFqQyxRQUFJb0IsU0FBSixDQUFjLEdBQWQ7QUFDQXBCLFFBQUlxQixHQUFKO0FBQ0QsR0F4QmEsQ0FBZDtBQXlCRCxDQXJDRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBTZXNzaW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzZXNzaW9ucycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBTZXNzaW9ucyB9IGZyb20gJy4uL2NvbGxlY3Rpb25zL1Nlc3Npb25zJztcblxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoXCIvaGVhclwiLCAocmVxLCByZXMsIG5leHQpID0+IHtcbiAgY29uc3QgbWFjaGluZSA9IHJlcS51cmwubWF0Y2goL15cXC8oLiopJC8pWzFdO1xuXG4gIGxldCBzZXNzaW9uID0gU2Vzc2lvbnMuZmluZE9uZSh7XG4gICAgbWFjaGluZVxuICB9KTtcblxuICAvLyBDcmVhdGUgc2Vzc2lvblxuICBpZiAoIXNlc3Npb24pIHtcbiAgICBzZXNzaW9uID0ge1xuICAgICAgbWFjaGluZSxcbiAgICAgIGNyZWF0ZV9hdDogbmV3IERhdGUoKSxcbiAgICAgIGxhc3RfcHVsbDogbmV3IERhdGUoMCksXG4gICAgICBjb21tYW5kczogW11cbiAgICB9O1xuXG4gICAgc2Vzc2lvbi5faWQgPSBTZXNzaW9ucy5pbnNlcnQoc2Vzc2lvbik7XG4gIH1cblxuICAvLyBVcGRhdGUgbGFzdCBjb25lY3Rpb25cbiAgU2Vzc2lvbnMudXBkYXRlKHNlc3Npb24uX2lkLCB7XG4gICAgJHNldDoge1xuICAgICAgbGFzdF9wdWxsOiBuZXcgRGF0ZSgpXG4gICAgfVxuICB9KTtcblxuICBsZXQgY21kSWQgPSAtMTtcbiAgc2Vzc2lvbi5jb21tYW5kcy5mb3JFYWNoKChjbWQsIGl4KSA9PiB7XG4gICAgaWYgKGNtZElkICE9PSAtMSkgcmV0dXJuO1xuICAgIGlmIChjbWQuc3RhdHVzID09PSAncGVuZGluZycpIGNtZElkID0gaXg7XG4gIH0pO1xuXG4gIGlmIChjbWRJZCA9PT0gLTEpIHtcbiAgICByZXMud3JpdGVIZWFkKDIwNCk7XG4gICAgcmV0dXJuIHJlcy5lbmQoKTtcbiAgfVxuXG4gIGNvbnN0IGNvbW1hbmQgPSBzZXNzaW9uLmNvbW1hbmRzW2NtZElkXTtcblxuICByZXMud3JpdGVIZWFkKDIwMCk7XG4gIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoe1xuICAgIGlkOiBjbWRJZCxcbiAgICBjbWQ6IGNvbW1hbmQuY29tbWFuZCxcbiAgfSkpO1xufSk7XG5cbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKFwiL3RhbGtcIiwgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XG4gIGNvbnN0IG1hY2hpbmUgPSByZXEudXJsLm1hdGNoKC9eXFwvKC4qKSQvKVsxXTtcblxuICBsZXQgc2Vzc2lvbiA9IFNlc3Npb25zLmZpbmRPbmUoe1xuICAgIG1hY2hpbmVcbiAgfSk7XG5cbiAgbGV0IGJvZHkgPSAnJztcbiAgcmVxLm9uKCdkYXRhJywgZnVuY3Rpb24oY2h1bmspIHtcbiAgICBib2R5ICs9IGNodW5rO1xuICB9KTtcblxuICByZXEub24oJ2VuZCcsIE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24oKSB7XG4gICAgdHJ5IHtcbiAgICAgIGJvZHkgPSBKU09OLnBhcnNlKGJvZHkpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXMud3JpdGVIZWFkKDQwMCk7XG4gICAgICByZXR1cm4gcmVzLmVuZCgpO1xuICAgIH1cblxuICAgIGNvbnN0IGNpZCA9IGJvZHkuaWQ7XG5cbiAgICBjb25zdCBzZXR0ZXIgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIFsnY29tbWFuZHMuJyArIGNpZCArICcuYW5zd2VyZWRfYXQnXTogbmV3IERhdGUoKSxcbiAgICAgICAgWydjb21tYW5kcy4nICsgY2lkICsgJy5zdGF0dXMnXTogJ2RvbmUnLFxuICAgICAgICBbJ2NvbW1hbmRzLicgKyBjaWQgKyAnLmNtZFN0YXR1cyddOiBib2R5LmNtZFN0YXR1cyxcbiAgICAgICAgWydjb21tYW5kcy4nICsgY2lkICsgJy5zdGRvdXQnXTogYm9keS5zdGRvdXQsXG4gICAgICAgIFsnY29tbWFuZHMuJyArIGNpZCArICcuc3RkZXJyJ106IGJvZHkuc3RkZXJyLFxuICAgICAgfVxuICAgIH07XG5cbiAgICBTZXNzaW9ucy51cGRhdGUoc2Vzc2lvbi5faWQsIHNldHRlcik7XG5cbiAgICByZXMud3JpdGVIZWFkKDIwMCk7XG4gICAgcmVzLmVuZCgpO1xuICB9KSk7XG59KTtcbiJdfQ==
